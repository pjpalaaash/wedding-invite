// Mock data for wedding website

export const weddingData = {
  couple: {
    groom: "Karan",
    bride: "Nisha",
    groomFather: "Puran Sharma",
    groomGrandfather: "Ved Sharma",
    groomCity: "Pune (MH)",
    brideFather: "Purushottam Verma",
    brideGrandfather: "Shrikant Verma",
    brideCity: "Mumbai (MH)"
  },
  weddingDate: {
    date: "22",
    month: "October",
    year: "2025",
    day: "Wednesday",
    targetDate: "2025-10-22T19:00:00+05:30"
  },
  venue: {
    name: "HOTEL THE TAJ PALACE",
    location: "Colaba, Mumbai (M.H.)",
    fullAddress: "HOTEL the TAJ mahal palace, colaba, Mumbai (M.H.)",
    mapUrl: "https://maps.app.goo.gl/MReCpBXq311tdk5GA"
  },
  events: [
    {
      id: 1,
      name: "Haldi Ceremony",
      date: "Tuesday, 21 October, 2025",
      time: "11:30 p.m. Onwards"
    },
    {
      id: 2,
      name: "Mehandi Ceremony",
      date: "Tuesday, 21 October, 2025",
      time: "02:00 p.m. onwards"
    },
    {
      id: 3,
      name: "Sangeet Night",
      date: "Tuesday, 21 October, 2025",
      time: "07:00 p.m. Onwards"
    },
    {
      id: 4,
      name: "Ring Ceremony",
      date: "Wednesday, 22 October, 2025",
      time: "10:00 a.m. Onwards"
    },
    {
      id: 5,
      name: "Mangal Phere",
      date: "Wednesday, 22 October, 2025",
      time: "07:00 p.m. Onwards"
    },
    {
      id: 6,
      name: "Reception & Dinner",
      date: "Wednesday, 22 October, 2025",
      time: "09:00 p.m. Onwards"
    }
  ],
  gallery: [
    "https://images.unsplash.com/photo-1519741497674-611481863552?w=800",
    "https://images.unsplash.com/photo-1606800052052-a08af7148866?w=800",
    "https://images.unsplash.com/photo-1583939003579-730e3918a45a?w=800",
    "https://images.unsplash.com/photo-1591604466107-ec97de577aff?w=800",
    "https://images.unsplash.com/photo-1605017492956-7a56f3a3f585?w=800",
    "https://images.unsplash.com/photo-1522413452208-996ff3f3e740?w=800"
  ],
  families: {
    groom: "Mr. Puran Sharma, Mr. Dilip Kumar & Mrs. Riya Sharma, Mr. shyam & Mrs. Tanvi Sharma, Mr. Rajesh Kumar & Mrs. Rekha Sharma, Mr. Ved Kumar & Mrs. Seema Sharma & All Sharma Family",
    bride: "Mr. Purushottam Verma & Family"
  },
  invitee: {
    name: "Puran Ved Kumar Sharma",
    address: "Sita Nagar, Near Gigabyte Hospital, Mumbai (M.H.)",
    phone: "+91 9000000001"
  },
  firm: {
    name: "P V Jewellers",
    address: "Road No 6, Gandhi Nagar, Mumbai(M.H.)"
  }
};
